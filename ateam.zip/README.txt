README

Course: cs400
Semester: Spring 2020
Project name: Milky Way
Team Members:
1. Jun Jeong, 001, jjeong@wisc.edu
2. Andrew McGrath, 001, admcgrath@wisc.edu
3. David Oh, 002, doh24@wisc.edu
4. Jiweon Yoo, 001, jyoo49@wisc.edu

 

Which team members were on same xteam together?
xTeam 104: Jun Jeong, Andrew McGrath

Other notes or comments to the grader:
